import * as React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default class Joke extends React.Component {
  constructor() {
    super();
    this.state = {
      like: 0,
      dislike: 0,
    };
  }
  render() {
    return (
      <View>
        <Text style={styles.text}>
          {' '}
          Q: Why was the math book sad? A: Because it had too many problems.
        </Text>

        <Text style={styles.text}>
          Q: What kind of meals do math teachers eat? A: Square meals!
        </Text>

        <Text style={styles.text}>
          Q: Teacher: Now class, whatever I ask, I want you to all answer at
          once. How much is six plus 4? A: Class: At once!
        </Text>

        <Text style={styles.text}>
          Q: Why didn't the two 4's want any dinner? A: Because they already 8!
        </Text>

        <Text style={styles.text}>
          Q: What is a math teacher's favorite sum? A: Summer!
        </Text>

        <Text style={styles.text}>
          Q: What is a butterfly's favorite subject at school? A: Mothematics.
        </Text>

        <Text style={styles.text}>
          Q: Teacher: Why are you doing your multiplication on the floor? A:
          Student: You told me not to use tables.
        </Text>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  text: {
    textAlign: 'center',
    color: 'black',
  },
});
