import firebase from 'firebase'

const firebaseConfig = {
    apiKey: "AIzaSyBhpx9AJ4I65b-6UTTNUFN1z2q9rnWYlrs",
    authDomain: "news-82886.firebaseapp.com",
    databaseURL: "https://news-82886.firebaseio.com",
    projectId: "news-82886",
    storageBucket: "news-82886.appspot.com",
    messagingSenderId: "531565873634",
    appId: "1:531565873634:web:c90bfe4271bd42fec551bb"
  };
   // Initialize Firebase
 if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
}
export default firebase.database();